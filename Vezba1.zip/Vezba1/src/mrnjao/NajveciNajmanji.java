package mrnjao;
import java.util.Scanner;

public class NajveciNajmanji {

	public static void main(String[] args) {
		int a , b , c , najveci , najmanji ;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Unesite a: ");
		a = sc.nextInt();
		System.out.println("Unesite b: ");
		b = sc.nextInt();
		System.out.println("Unesite c: ");
		c = sc.nextInt();
		
		najmanji = a;
		najveci = a;
		
		if (najmanji > b) {
			najmanji = b;
		} else if (najmanji > c) {
			najmanji = c;
		}else if (najveci < b) {
			najveci = b;
		} else if (najveci < c) {
			najveci = c;
		}
		
		System.out.println("Najmanji broj je: " + najmanji);
		System.out.println("Najveci broj je: " + najveci);

	}

}
