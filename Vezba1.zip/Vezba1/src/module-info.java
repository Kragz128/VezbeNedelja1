/**
 * 
 */
/**
 * 
 */
module Vezba1 {
}